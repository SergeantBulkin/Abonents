package com.example.bottomapp.bar.test;

import android.content.Context;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

public class CoordinatorLayout extends FrameLayout {
    public CoordinatorLayout(@NonNull Context context) {
        super(context);
    }
}
